# model_parameters

    Code
      mp
    Output
      # Fixed Effects
      
      Parameter   | Coefficient |   SE |       95% CI | t(383.05) |      p
      --------------------------------------------------------------------
      (Intercept) |        7.97 | 0.10 | [7.77, 8.17] |     78.10 | < .001
      
      # Smooth Terms
      
      Parameter        |     F |   df |      p
      ----------------------------------------
      Smooth term (x0) | 10.53 | 3.63 | < .001
      Smooth term (x1) | 87.44 | 2.97 | < .001
      Smooth term (x2) | 72.49 | 8.30 | < .001
      Smooth term (x3) |  9.58 | 1.05 | 0.002 

