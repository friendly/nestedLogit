#' @export
model_parameters.mcmc <- model_parameters.data.frame
