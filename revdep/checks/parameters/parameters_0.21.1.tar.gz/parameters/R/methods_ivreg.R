#' @export
p_value.ivreg <- p_value.default

#' @export
simulate_model.ivreg <- simulate_model.default

#' @export
standard_error.ivreg <- standard_error.default
