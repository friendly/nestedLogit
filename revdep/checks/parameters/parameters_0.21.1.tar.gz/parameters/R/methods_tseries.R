# classes: .garch

#' @export
degrees_of_freedom.garch <- degrees_of_freedom.mhurdle
