#' @export
ci.scam <- ci.gam


#' @export
standard_error.scam <- standard_error.gam


#' @export
p_value.scam <- p_value.gam


#' @rdname model_parameters.cgam
#' @export
model_parameters.scam <- model_parameters.cgam
