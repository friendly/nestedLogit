#' @export
model_parameters.BGGM <- model_parameters.bayesQR

#' @export
p_value.BGGM <- p_value.BFBayesFactor
